theta = [46.5 40.8 50.7 29.9];
M = 100;
save equilibrium9