% Creating progr4data File
time = [0:12];
depth = [9.8, 11.4, 11.6, 11.2, 9.6, 8.5, 6.5, 5.7, 5.4, 6, 7, 8.6, 10];
save prog5data time depth