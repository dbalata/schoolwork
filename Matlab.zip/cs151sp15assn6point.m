% Dylan Balata
% CS 151-005
% Assignment 6 Point
% Determines points

function point = cs151sp15assn6point(x,y)
plot(x,y,'go') % plots points
